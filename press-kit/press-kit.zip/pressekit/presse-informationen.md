# Über tvshows
Berlin, swenden präsentiert seine erste iOS App. tvshows hilft SerienliebhaberInnen ihre Serien zu verwalten, zeigt ihnen wann Episoden im TV ausgestrahlt werden und gibt Empfehlungen für neue Formate.

tvshows hilft dabei den Überblick zu behalten und zeigt den aktuellen Fortschritt bei jeder Serie an. 

# App Store-Beschreibung
tvshows hilft Dir deine Lieblingserien zu verfolgen, neue Formate zu entdecken und zeigt Dir an, wann und wo Episoden deiner Serien im TV ausgestrahlt werden. Du erhältst Informationen zu Serien und einzelnen Episoden, sowie mit Hilfe von Statistiken einen Einblick in dein Sehverhalten.

Folgende Features machen tvshows einzigartig:
- Verwalte deine Lieblingsserien und markiere bereits gesehene Episoden.
- Erfahre wann Folgen deiner Lieblingsserien im TV ausgestrahlt werden. Verpasse keine Episode.
- Erhalte Informationen zu Serien und einzelnen Episoden. 
- Bekomme Empfehlungen über neue und sehenswerte Serien.
- Werde benachrichtigt wann und wo Episoden im TV laufen.
- [ABO / TRINKGELD] Als Abonnement oder mit einem kleinen Trinkgeld kannst du tvshows individuell anpassen und zwischen einer von drei Highlight-Farben wählen.
- [ABO] Das Abonnement ermöglicht Dir den Zugang zu individuellen Statistiken. Du bekommst einen Überblick zu deinen abonnierten Serien und Sehverhalten. tvshows verrät Dir wie viele Stunden du schon geschaut hast und noch vor dir liegen um alles zu sehen.

Für Fragen und Feedback sind wir via eMail unter feedback@tvshows-app.com und über twitter unter dem Nutzernamen @_tvshows_app erreichbar. Wenn du ein Problem mit tvshows hast, melde dich bei uns. Wir können auf AppStore-Kommentare nicht reagieren.

Viel Spaß mit tvshows.


# Fact-Sheet
## Release-Datum
* initiales Release der 1.0 am 24. Mai 2016
* aktuelles Release der 1.0.1 am 27. Mai 2016

## Preise & Verfügbarkeit	
tvshows kann kostenlos im deutschen Apple App Store heruntergeladen werden.Nutzer können mit einer freiwilligen Spende die Weiterentwicklung unterstützen.Ein Abo ermöglicht den NutzerInnen, mit Hilfe von Statistiken, Einblicke in ihr Sehrverhalten zu bekommen. Diese kosten 1,99€&nbsp;für 3 Monate, 3,99€ für 6 Monate und 6,99€ für 12 Monate.

## Entwickler
tvshows wurde von der [swenden UG (haftungsbeschränkt)](http://www.swenden.de) entwickelt. Einem kleinen auf Apps spezialisierten Entwickler-Studio aus Berlin.

# Screenshots
* [Serien-Übersicht](http://www.tvshows-app.com/press-kit/screenshots/serien_ubersicht.png)
* [Serien-Details](http://www.tvshows-app.com/press-kit/screenshots/serien_details.png)
* [Episoden-Übersicht](http://www.tvshows-app.com/press-kit/screenshots/episoden_ubersicht.png)
* [Episoden-Details](http://www.tvshows-app.com/press-kit/screenshots/episode_details.png)
* [Sendetermine](http://www.tvshows-app.com/press-kit/screenshots/sendetermine.png)
* [Empfehlungen](http://www.tvshows-app.com/press-kit/screenshots/empfehlungen.png)
* [Suche](http://www.tvshows-app.com/press-kit/screenshots/suche.png)
* [Statistiken](http://www.tvshows-app.com/press-kit/screenshots/statistiken.png)
* [Alternative Highlight-Farbe](http://www.tvshows-app.com/press-kit/screenshots/highlight_farbe.png)

# Icon
* [300px](http://www.tvshows-app.com/press-kit/icons/icon_300px.png)
* [500px](http://www.tvshows-app.com/press-kit/icons/icon_500px.png)
* [1000px](http://www.tvshows-app.com/press-kit/icons/icon_1000px.png)

# Review-Zugänge
Für den Zugang zu einer Review-Kopie, schreiben Sie uns bitte eine [eMail](kontakt@swenden.de?subject=Review%20tvshows).

# Presse-Kontakt
Dennis Kluge

eMail: [dennis@swenden.de](mailto:dennis@swenden.de)
Telefon: [030 55571060](tel:03055571060)
Twitter: [@swenden_de](http://www.twitter.com/swenden-de)
website: [swenden.de](http://www.swenden.de)
