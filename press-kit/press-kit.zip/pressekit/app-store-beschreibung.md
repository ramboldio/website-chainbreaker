# App Store-Beschreibung
tvshows hilft Dir deine Lieblingserien zu verfolgen, neue Formate zu entdecken und zeigt Dir an, wann und wo Episoden deiner Serien im TV ausgestrahlt werden. Du erhältst Informationen zu Serien und einzelnen Episoden, sowie mit Hilfe von Statistiken einen Einblick in dein Sehverhalten.

Folgende Features machen tvshows einzigartig:
- Verwalte deine Lieblingsserien und markiere bereits gesehene Episoden.
- Erfahre wann Folgen deiner Lieblingsserien im TV ausgestrahlt werden. Verpasse keine Episode.
- Erhalte Informationen zu Serien und einzelnen Episoden. 
- Bekomme Empfehlungen über neue und sehenswerte Serien.
- Werde benachrichtigt wann und wo Episoden im TV laufen.
- [ABO / TRINKGELD] Als Abonnement oder mit einem kleinen Trinkgeld kannst du tvshows individuell anpassen und zwischen einer von drei Highlight-Farben wählen.
- [ABO] Das Abonnement ermöglicht Dir den Zugang zu individuellen Statistiken. Du bekommst einen Überblick zu deinen abonnierten Serien und Sehverhalten. tvshows verrät Dir wie viele Stunden du schon geschaut hast und noch vor dir liegen um alles zu sehen.

Für Fragen und Feedback sind wir via eMail unter feedback@tvshows-app.com und über twitter unter dem Nutzernamen @_tvshows_app erreichbar. Wenn du ein Problem mit tvshows hast, melde dich bei uns. Wir können auf AppStore-Kommentare nicht reagieren.

Viel Spaß mit tvshows.
